// import adminModel from "../models/adminModel";

// export default checkAdmin = async(req,res)=>{
//     try {
//          const {mobile , password} = req.body;

//          if(!mobile || !password){

//          }

//     } catch (error) {
        
//     }
// }